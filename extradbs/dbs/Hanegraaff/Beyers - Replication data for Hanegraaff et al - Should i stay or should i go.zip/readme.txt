HANEGRAAFF, VERGAUWEN & BEYERS (2019), "SHOULD I STAY OR SHOULD I GO? EXPLAINING VARIATION IN NON-STATE ACTOR ADVOCACY OVER TIME IN GLOBAL GOVERNANCE", GOVERNANCE
STATA SYNTAX FOR REPRODUCING MAIN PAPER RESULTS
THE DATASET INCLUDES PUBLICLY AVAILABLE INFORMATION, COMPILED AT THE UNIVERSITY OF ANTWERP
FOR MORE INFORMATION ON THE COLLECTED DATA, PLEASE CONTACT JAN.BEYERS@UANTWERPEN.BE

Please note that all syntax lines referring to datafiles or local directories should link to the correct location on your local machine first (i.e. command lines "use", "cd" and "merge")
Please note that the syntax includes non-standard stata packages: bspline. To install use following command: "ssc install bspline".